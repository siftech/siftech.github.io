# Revised Soccer Team Exercise Files

This directory contains a set of files suitable to be used as background knowledge
with LEGEND.  As we have explained in the user manual, references to file names cannot be
used with the LEGEND web application. Hard-coded module names are also unsuitable (except
for modules that are included with Ergo itself).

These files contain the background knowledge, with some corrections, together
with support files required to run the focal queries we were supplied.

