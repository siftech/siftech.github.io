# Revised Joint Command Exercise Files

This directory contains, first, a set of files suitable to be used as background knowledge
with LEGEND.  As we have explained in the user manual, references to file names cannot be
used with the LEGEND web application. Hard-coded module names are also unsuitable (except
for modules that are included with Ergo itself).

We also supply a text file with the original public text from which frame instances are
to be extracted, accompanied by a massaged version of this text that has been decomposed
into individual statements, each of which attempts to describe only a single frame instance.
This is an example of the data preparation referred to in the user manual.

